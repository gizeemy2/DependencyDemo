﻿using DependencyDemo.Services.Interfaces;

namespace DependencyDemo.Services
{
    public class TextLog:ILog
    {


        public void Log()
        {
            Console.WriteLine("Text dosyasına loglama işlemi gerçekleştirildi");
        }
    }
}
