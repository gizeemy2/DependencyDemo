﻿namespace DependencyDemo.Services.Interfaces
{
    public interface ILog
    {

        public void Log();
        

    }
}
