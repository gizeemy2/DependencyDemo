﻿using DependencyDemo.Services.Interfaces;

namespace DependencyDemo.Services
{
    public class ConsoleLog:ILog
    {
        public ConsoleLog(int a)
        {

        }
        public void Log()
        {
            Console.WriteLine("Console a loglama işlemi gerçekleştirildi.");
        }
    }
}
