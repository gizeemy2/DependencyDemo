using DependencyDemo.Services;
using DependencyDemo.Services.Interfaces;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllersWithViews();

//builder.Services.Add(new ServiceDescriptor(typeof(ConsoleLog), new ConsoleLog()));     //DEFAULT OLARAK S�NGLETON OLUR ADD �LE EKL�YORSAK
//builder.Services.Add(new ServiceDescriptor(typeof(TextLog), new TextLog()));


//builder.Services.AddSingleton<ConsoleLog>(p=>new ConsoleLog(5));    //burada tek bir console log nesnesini t�m isteklere g�nderecek

//builder.Services.AddScoped<ConsoleLog>();     //burada ise t�m isteklerde ayr� bir taen console log nesnesi olu�turacak ve her bir iste�in talebine o nesneden g�nderecek.
//builder.Services.AddScoped<ConsoleLog>(p=>new ConsoleLog(5));

//builder.Services.AddTransient<ConsoleLog>();   //Her iste�in her talebine talebe �zel nesene �retip g�nderecektir.
//builder.Services.AddTransient<ConsoleLog>(p=>new ConsoleLog(5));

//builder.Services.AddScoped<ILog>(p => new ConsoleLog(5));

//builder.Services.AddScoped<ILog, TextLog>();  //Burada hangi aray�zden(container) alaca��n� ve hangi nesnenin olaca��n� bildiriyoruz.Burada dikkat edilmesi gereken TextLog parametresinin ILogdan t�remi� olmas� gerekir.2. oalrak bu TextLog parametresinin nesne �retilebilir ve bo� parametre olmas� gerekiyor. 
builder.Services.AddScoped<ILog,ConsoleLog>(p=>new ConsoleLog(5));



var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
