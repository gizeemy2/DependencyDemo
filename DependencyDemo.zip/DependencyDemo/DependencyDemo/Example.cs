﻿using System;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using DependencyDemo.Services;

namespace DependencyDemo
{
    public class Example
    {
        public Example()
        {
            IServiceCollection services = new ServiceCollection(); //BUİLT-İN IOC mekanizması
            services.Add(new ServiceDescriptor(typeof(ConsoleLog), new ConsoleLog(5)));                                        //burada ilgili konteynıra bunlarla ilgili sınıfları ekliyorsun lazım olduğu takdirde kullanabilmek için.
            services.Add(new ServiceDescriptor(typeof(TextLog), new TextLog()));


          ServiceProvider provider= services.BuildServiceProvider();   //ilgili konteynırı oluşturur. //Somut container/provider/sağlayıcı
            provider.GetService<ConsoleLog>();    //DAT.NET CORE MİMARİDEKİ ıoc YPILANMASI
            provider.GetService<TextLog>();
        }
    }
}
