﻿using DependencyDemo.Models;
using DependencyDemo.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DependencyDemo.Controllers
{
    public class HomeController : Controller
    {
        readonly ILog _log;
        public HomeController(ILog log)  //ILOG TÜRÜNDEKİ NESNEYİ GETİRDİK.SONRA BU GLOBAL PROPERTY İ İSTEDİĞİMİZ YERDE KULLANACAĞIZ.
        {
            _log = log;
        }



        //private readonly ILogger<HomeController> _logger;

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}

        public IActionResult Index([FromServices]ILog log) //ACTİON SEVİYSİNDE İLGİLİ NESNEYİ ÇAĞIRMA
        {
            _log.Log();
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}